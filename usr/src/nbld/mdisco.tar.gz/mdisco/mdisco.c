/*
 * ########################################################################
 * # CDDL HEADER START
 * #
 * # The contents of this file are subject to the terms of the
 * # Common Development and Distribution License (the "License").
 * # You may not use this file except in compliance with the License.
 * #
 * # You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * # or http://www.opensolaris.org/os/licensing.
 * # See the License for the specific language governing permissions
 * # and limitations under the License.
 * #
 * # When distributing Covered Code, include this CDDL HEADER in each
 * # file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * # If applicable, add the following below this CDDL HEADER, with the
 * # fields enclosed by brackets "[]" replaced with your own identifying
 * # information: Portions Copyright [yyyy] [name of copyright owner]
 * #
 * # CDDL HEADER END
 * #
 * # Copyright (C) 2005-2008 Nexenta Systems, Inc.
 * # All rights reserved.
 * #
 * ########################################################################
 */

#include <stdio.h>
#include <stdlib.h>
#include <libdevinfo.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/dkio.h>
#include <sys/cdio.h>
#include <sys/fs/hsfs_isospec.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>
#include <locale.h>

di_node_t root_node = DI_NODE_NIL;
boolean_t hdd = B_FALSE;
boolean_t verbose = B_FALSE;
boolean_t getlink = B_FALSE;
boolean_t raw = B_FALSE;
boolean_t found = B_FALSE;
char *volid = NULL;

static void
finish(void)
{
	if (root_node != DI_NODE_NIL)
		di_fini(root_node);

	exit(found ? EXIT_SUCCESS : EXIT_FAILURE);
}

uchar_t secbuf[ISO_SECTOR_SIZE];

static boolean_t
read_sector(int fd, off_t offset, struct dk_minfo *minfop)
{
	uint64_t media_size;

	media_size = (uint64_t)minfop->dki_capacity * minfop->dki_lbsize;

	if ((offset + ISO_SECTOR_SIZE) > media_size ||
	    lseek(fd, offset, SEEK_SET) < 0L ||
	    read(fd, secbuf, ISO_SECTOR_SIZE) != ISO_SECTOR_SIZE)
		return (B_FALSE);

	return (B_TRUE);
}

static boolean_t
read_volid(int fd, struct dk_minfo *minfop)
{
	off_t offset = ISO_VOLDESC_SEC * ISO_SECTOR_SIZE;
	uchar_t iso_volid[ISO_VOL_ID_STRLEN+1];

	if (!read_sector(fd, offset, minfop))
		return (B_FALSE);

	/* Make sure ISO ID string and version match */
	if (bcmp(ISO_STD_ID(secbuf), ISO_ID_STRING, ISO_ID_STRLEN) != 0 ||
	    ISO_STD_VER(secbuf) != ISO_ID_VER ||
	    ISO_DESC_TYPE(secbuf) != ISO_VD_PVD)
		return (B_FALSE);

	/* Check ISO volume ID */
	bcopy(ISO_VOL_ID(secbuf), iso_volid, ISO_VOL_ID_STRLEN);
	iso_volid[ISO_VOL_ID_STRLEN] = '\0';

	return (bcmp(iso_volid, volid, strlen(volid)) == 0);
}

static boolean_t
match_volid(char *rawdev)
{
	int fd;
	uchar_t track;
	struct stat statbuf;
	struct stat *statp = &statbuf;
	struct dk_cinfo cinfo;
	struct dk_minfo minfo;
	struct cdrom_tochdr cdtoc;
	boolean_t match = B_FALSE;

	if (volid == NULL)
		return (B_TRUE);

	if ((fd = open(rawdev, O_RDONLY | O_NDELAY)) < 0 ||
	    fstat(fd, statp) == -1 || !S_ISCHR(statp->st_mode) ||
	    ioctl(fd, DKIOCINFO, &cinfo) < 0 || cinfo.dki_ctype != DKC_CDROM ||
	    ioctl(fd, DKIOCGMEDIAINFO, &minfo) < 0 ||
	    ioctl(fd, CDROMREADTOCHDR, &cdtoc) < 0)
		goto done;

	/* Iterate through all tracks to find data (non-audio) */
	track = cdtoc.cdth_trk0;
	do {
		struct cdrom_tocentry cdtocent;

		if (track == (CDROM_LEADOUT + 1))
			break;

		if (track > cdtoc.cdth_trk1)
			track = CDROM_LEADOUT;

		cdtocent.cdte_track = track++;
		cdtocent.cdte_format = CDROM_MSF;

		if (ioctl(fd, CDROMREADTOCENTRY, &cdtocent) >= 0 &&
		    !(cdtocent.cdte_ctrl & CDROM_DATA_TRACK))
			continue;

		/* Digital data found; now check volume ID */
		match = read_volid(fd, &minfo);
	} while (!match);

done:
	if (fd != -1)
		(void) close(fd);

	return (match);
}

static boolean_t
match_volid_bydevpath(char *devpath)
{
	char rawdev[MAXPATHLEN];

	(void) sprintf(rawdev, "/devices");
	(void) strcat(rawdev, devpath);
	(void) strcat(rawdev, ":q,raw");

	return (match_volid(rawdev));
}

static boolean_t
match_bydevlink(char *devlink)
{
	char rawdev[MAXPATHLEN];

	(void) sprintf(rawdev, "/dev/rdsk/");
	(void) strcat(rawdev, devlink);

	return (hdd ? B_TRUE : match_volid(rawdev));
}

static int
finddisk_cb(di_node_t node, di_minor_t minor, void *arg)
{
	char devpath[MAXPATHLEN];
	char dirpath[MAXPATHLEN];
	DIR *dirp;
	struct dirent *direntry;
	char *name = di_minor_name(minor);
	char *devfspath = di_devfs_path(node);
	int rc;

	/* Skip all but partition 0 */
	if (di_minor_spectype(minor) != S_IFCHR ||
	    (!hdd ? (strncmp(di_minor_nodetype(minor), DDI_NT_CD,
	    sizeof (DDI_NT_CD) - 1) != 0) :
	    (strncmp(di_minor_nodetype(minor), DDI_NT_BLOCK,
	    sizeof (DDI_NT_BLOCK) - 1) != 0)) || strcmp(name, "q,raw") != 0) {
		if (verbose)
			printf("skipped %s: %s %s\n", devfspath, name,
			    di_minor_nodetype(minor));

		di_devfs_path_free(devfspath);
		goto done;
	}

	if (verbose)
		printf("found %s: %s %s\n", devfspath, name,
		    di_minor_nodetype(minor));

	(void) sprintf(devpath, "/devices");
	(void) strcat(devpath, devfspath);
	(void) strcat(devpath, ":");
	(void) strcat(devpath, raw ? name : "q");
	di_devfs_path_free(devfspath);

	if (!getlink) {
		if (found = match_volid_bydevpath(devfspath))
			printf("%s\n", devpath);
		goto done;
	}

	(void) snprintf(dirpath, MAXPATHLEN, raw ? "/dev/rdsk" : "/dev/dsk");
	if ((dirp = opendir(dirpath)) == NULL) {
		perror("opendir()");
		goto done;
	}

	while ((direntry = readdir(dirp)) != NULL) {
		char devlink[MAXPATHLEN];
		char physdev[MAXPATHLEN];
		int len;
		char *c;

		if (strcmp(direntry->d_name, ".") == 0 ||
		    strcmp(direntry->d_name, "..") == 0)
			continue;

		(void) snprintf(devlink, MAXPATHLEN, "%s/%s",
		    dirpath, direntry->d_name);

		len = readlink(devlink, physdev, MAXPATHLEN);
		if (len < 0 || len >= MAXPATHLEN) {
			perror("readlink()");
			continue;
		}
		physdev[len] = '\0';

		if ((c = strstr(physdev, "/devices")) != NULL &&
		    strcmp(c, devpath) == 0) {
			if (found = match_bydevlink(direntry->d_name))
				printf("%s\n", devlink);
			break;
		}
	}
	(void) closedir(dirp);

done:
	if (!found || volid == NULL)
		rc = DI_WALK_CONTINUE;
	else
		rc = DI_WALK_TERMINATE;

	return (rc);
}

int
main(int argc, char *argv[])
{
	int i, rc;

	setbuf(stdout, NULL);
	(void) setlocale(LC_ALL, "");

	while ((i = getopt(argc, argv, "dlrvV:")) != -1)  {
		switch (i) {
		case 'd':
			hdd = B_TRUE;
			break;
		case 'l':
			getlink = B_TRUE;
			break;
		case 'r':
			raw = B_TRUE;
			break;
		case 'v':
			verbose = B_TRUE;
			break;
		case 'V':
			volid = optarg;
			if (strlen(volid) > ISO_VOL_ID_STRLEN) {
				fprintf(stderr, "ISO volume ID exceeds maximum "
				    "length (%d chars)\n", ISO_VOL_ID_STRLEN);
				finish();
			}
			break;
		default:
			fprintf(stderr, "Unknown options\n");
			finish();
		}
	}

	if ((root_node = di_init("/", DINFOCPYALL)) == DI_NODE_NIL) {
		perror("di_init(root_node)");
		finish();
	}

	/* Find all disk devices */
	rc = di_walk_minor(root_node, DDI_NT_BLOCK, 0, NULL, finddisk_cb);
	if (rc != 0) {
		perror("di_walk_minor(root_node)");
		finish();
	}

	finish();
}
